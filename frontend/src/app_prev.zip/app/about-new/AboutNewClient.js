'use client';

import { useState } from 'react';

const leaders = [
  ['Mahesh Vinayagam', 'CEO and Founder'],
  ['Bejoe Mathew', 'Chief Strategy Officer'],
  ['Dominic Bartola', 'Chief Marketing Officer'],
  ['Sathyanarayanan', 'Chief Growth Officer'],
  ['Manu Paul', 'Chief Financial Officer'],
  ['Vidyasagar C', 'AVP, Operations'],
  ['Russel Alfeche', 'Technology Lead, RPA and AI'],
  ['Tricia D’souza', 'Global HR Manager'],
  ['Selva', 'SVP of Healthcare'],
];

const palette = [
  ['#e6b99c', '#283e57', '#352b29'],
  ['#c58d6a', '#1e5875', '#292b35'],
  ['#edc9b0', '#47566d', '#493b33'],
  ['#b87d59', '#2e475e', '#292b30'],
  ['#d4a07b', '#354c78', '#3a312c'],
  ['#b97e5d', '#516079', '#242a30'],
  ['#d5a78d', '#2a5b64', '#33343d'],
  ['#dfad92', '#794a66', '#372d31'],
  ['#c58d6a', '#3c5075', '#242b35'],
];

const hairShapes = [
  'M47 73 Q42 23 95 25 Q143 27 139 73 L124 67 Q114 43 85 46 Q60 46 57 75Z',
  'M45 77 Q42 29 90 29 Q142 26 141 77 L128 68 Q117 49 93 50 Q61 49 57 79Z',
  'M45 75 Q43 25 93 28 Q141 27 140 75 L127 67 Q114 43 88 48 Q60 47 57 74Z',
];

function SamplePortrait({ i }) {
  const [skin, jacket, hair] = palette[i];
  return (
    <svg viewBox="0 0 184 184" role="img" aria-label="Illustrated sample portrait, not an actual photograph">
      <rect width="184" height="184" rx="15" fill="#f5e9e1" />
      <circle cx="142" cy="37" r="62" fill="#f9d9c4" opacity=".8" />
      <path d="M15 184 Q24 126 92 126 Q160 126 169 184" fill={jacket} />
      <path d="M77 116h31v31H77z" fill={skin} />
      <path d="M77 137 92 151 108 137 116 184H68Z" fill="#fff" />
      <ellipse cx="92" cy="81" rx="43" ry="51" fill={skin} />
      <path d={hairShapes[i % 3]} fill={hair} />
      <path d="M67 83h12M104 83h12" stroke={hair} strokeWidth="3" strokeLinecap="round" />
      <circle cx="74" cy="87" r="2" fill="#30313a" />
      <circle cx="110" cy="87" r="2" fill="#30313a" />
      <path d="M85 107 Q92 112 100 107" fill="none" stroke="#8b5348" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}

const locations = [
  {
    country: 'usa',
    photoClass: 'phoenix',
    img: 'https://commons.wikimedia.org/wiki/Special:FilePath/Phoenix%20skyline%20Arizona%20USA.jpg?width=900',
    alt: 'Phoenix skyline, Arizona',
    caption: 'Phoenix, Arizona',
    label: 'UNITED STATES',
    city: 'Phoenix',
    region: 'Arizona, USA',
  },
  {
    country: 'india',
    photoClass: 'chennai',
    img: 'https://commons.wikimedia.org/wiki/Special:FilePath/Marina%20beach%20Chennai.jpg?width=900',
    alt: 'Marina Beach, Chennai',
    caption: 'Chennai, Tamil Nadu',
    label: 'INDIA',
    city: 'Chennai',
    region: 'Tamil Nadu, India',
  },
  {
    country: 'canada',
    photoClass: 'newbrunswick',
    img: 'https://commons.wikimedia.org/wiki/Special:FilePath/Hopewell%20Rocks%20%286000931458%29.jpg?width=900',
    alt: 'Hopewell Rocks, New Brunswick',
    caption: 'New Brunswick, Canada',
    label: 'CANADA',
    city: 'New Brunswick',
    region: 'Canada',
  },
];

export default function AboutNewClient() {
  const [tab, setTab] = useState('programs');
  const [country, setCountry] = useState('usa');

  const cls = (base, on) => (on ? `${base} active` : base);

  return (
    <div className="qb-about">
      <section className="hero">
        <div className="container">
          <div className="eyebrow">ABOUT QBOTICA · THE PEOPLE BEHIND THE EXECUTION</div>
          <h1>
            Built for innovation.
            <br />
            Driven by people.
          </h1>
          <p>
            Behind every transformation is a team of people who believe in making work better. Discover the
            leadership, values, culture and community that shape qBotica.
          </p>
          <div className="hero-actions">
            <a className="btn primary" href="#story">Discover Our Story ↓</a>
            <a className="btn ghost" href="#impact">See Our Impact ↓</a>
          </div>
          <div className="hero-proof">
            <div className="proof">UiPath Diamond Partner</div>
            <div className="proof">Enterprise automation expertise</div>
            <div className="proof">U.S. + India collaboration</div>
          </div>
        </div>
      </section>

      <section className="section scroll" id="story">
        <div className="container">
          <div className="head">
            <div>
              <div className="kicker">WHO WE ARE</div>
              <h2>
                Technology moves forward.
                <br />
                People make it possible.
              </h2>
            </div>
            <p>
              qBotica helps organizations become automation- and future-ready. Our story is grounded in technical
              expertise, meaningful partnerships and the people who make progress possible.
            </p>
          </div>
          <div className="story-grid">
            <article className="panel feature">
              <div className="kicker" style={{ color: '#f7a56e' }}>Our purpose</div>
              <h3 style={{ fontSize: 29, margin: '10px 0' }}>
                Enabling organizations to become automation and future ready.
              </h3>
              <p>
                Our people bring together intelligent automation, AI, practical delivery and the curiosity to rethink
                how work gets done.
              </p>
              <div className="tags">
                <span className="tag">Innovation</span>
                <span className="tag">Partnership</span>
                <span className="tag">Execution</span>
              </div>
            </article>
            <article className="panel">
              <div className="kicker">Recognition &amp; credibility</div>
              <h3>Certified. Trusted. Forward-looking.</h3>
              <p>qBotica&apos;s UiPath Diamond Partner status reflects its advanced automation practice and technical expertise.</p>
              <p>See how our expertise translates into outcomes for customers.</p>
              <a className="textlink" href="/customer-success-stories">Explore customer success stories ↗</a>
            </article>
          </div>
        </div>
      </section>

      <section className="section alt scroll" id="leadership">
        <div className="container">
          <div className="head">
            <div>
              <div className="kicker">OUR LEADERSHIP</div>
              <h2>
                Meet the people
                <br />
                leading qBotica.
              </h2>
            </div>
            <p>
              Experienced leaders, united by a commitment to building an exceptional team and delivering meaningful
              results.
            </p>
          </div>
          <div className="leaders">
            {leaders.map(([name, title], i) => (
              <article className="leader" key={name}>
                <div className="avatar portrait">
                  <SamplePortrait i={i} />
                </div>
                <div>
                  <strong>{name}</strong>
                  <small>{title}</small>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section scroll" id="values">
        <div className="container">
          <div className="head">
            <div>
              <div className="kicker">COMPANY ETHOS</div>
              <h2>
                Four values.
                <br />
                One shared mindset.
              </h2>
            </div>
            <p>Our values shape how we collaborate, solve problems, support one another and show up for customers.</p>
          </div>
          <div className="values">
            <article className="value">
              <div className="symbol">✦</div>
              <h3>Innovative</h3>
              <p>We challenge convention and find imaginative approaches to automation.</p>
            </article>
            <article className="value">
              <div className="symbol">↗</div>
              <h3>Bold</h3>
              <p>We embrace new ideas, explore opportunities and act with courage.</p>
            </article>
            <article className="value">
              <div className="symbol">◇</div>
              <h3>Smart</h3>
              <p>We combine experience, intelligence and efficiency to work with purpose.</p>
            </article>
            <article className="value">
              <div className="symbol">♡</div>
              <h3>Kind</h3>
              <p>We value empathy, understanding and inclusive relationships.</p>
            </article>
          </div>
        </div>
      </section>

      <section className="section alt scroll" id="people">
        <div className="container">
          <div className="head">
            <div>
              <div className="kicker">LIFE AT QBOTICA</div>
              <h2>
                Our culture is something
                <br />
                we build together.
              </h2>
            </div>
            <p>
              Beyond the technology, our people make qBotica what it is. Explore the wellness, learning, celebrations
              and shared passions that strengthen our teams.
            </p>
          </div>
          <div className="culture-grid">
            <article className="culture">
              <div className="media-placeholder">APPROVED WELLNESS PHOTO</div>
              <div className="body">
                <h3>Well-being &amp; support</h3>
                <p>Internal wellness and learning sessions that support employees as people, not just professionals.</p>
              </div>
            </article>
            <article className="culture">
              <div className="media-placeholder">APPROVED TEAM PHOTO</div>
              <div className="body">
                <h3>Connection &amp; celebration</h3>
                <p>Team activities, cultural moments and opportunities to share personal talents and interests.</p>
              </div>
            </article>
            <article className="culture">
              <div className="media-placeholder">APPROVED MENTORSHIP PHOTO</div>
              <div className="body">
                <h3>Growth &amp; opportunity</h3>
                <p>Mentorship, professional development and a culture of learning and collaboration.</p>
              </div>
            </article>
          </div>
          <div
            className="panel"
            style={{ marginTop: 19, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 20, flexWrap: 'wrap' }}
          >
            <div>
              <h3 style={{ margin: '0 0 4px' }}>Join our winning team</h3>
              <p style={{ margin: 0 }}>Explore opportunities to grow with qBotica.</p>
            </div>
            <a className="btn primary" href="/careers">Explore Careers ↗</a>
          </div>
        </div>
      </section>

      <section className="section scroll" id="inclusion">
        <div className="container">
          <div className="head">
            <div>
              <div className="kicker">DIVERSITY &amp; OPPORTUNITY</div>
              <h2>
                Different perspectives.
                <br />
                Stronger together.
              </h2>
            </div>
            <p>
              Preserving the important initiatives and commitments from qBotica&apos;s existing About Us page, without
              overwhelming visitors with long text blocks.
            </p>
          </div>
          <div aria-label="Inclusion topics" className="tabs" role="tablist">
            <button type="button" role="tab" className="tab" aria-selected={tab === 'programs'} onClick={() => setTab('programs')}>
              Our programs
            </button>
            <button type="button" role="tab" className="tab" aria-selected={tab === 'commitment'} onClick={() => setTab('commitment')}>
              Our commitment
            </button>
          </div>
          <div className={cls('tab-panel', tab === 'programs')} id="programs" role="tabpanel">
            <div className="initiative-grid">
              <article className="initiative">
                <h3>Women&apos;s Reboot Program</h3>
                <p>Training, mentoring and networking opportunities to support women returning to careers in technology.</p>
              </article>
              <article className="initiative">
                <h3>Employee Resource Groups</h3>
                <p>Voluntary employee-led groups creating space for connection, shared experiences and support.</p>
              </article>
              <article className="initiative">
                <h3>Diverse hiring practices</h3>
                <p>Inclusive recruitment and pathways to experience through internships and apprenticeships.</p>
              </article>
              <article className="initiative">
                <h3>Inclusion training</h3>
                <p>Employee education and conversations designed to build an inclusive, respectful workplace.</p>
              </article>
            </div>
          </div>
          <div className={cls('tab-panel', tab === 'commitment')} id="commitment" role="tabpanel">
            <div className="panel">
              <h3>Inclusion is part of how we work.</h3>
              <p>
                qBotica&apos;s existing page describes its commitment to welcoming people across backgrounds, supporting
                open dialogue, and engaging with communities through volunteering and leadership.
              </p>
              <p>This content should retain its original intent and be reviewed with HR before publication.</p>
            </div>
          </div>
          <div className="quote">
            “Diversity and inclusion are not just buzzwords at qBotica, they are the foundation of our success.”
            <small>— Mahesh Vinayagam, CEO of qBotica · Excerpt from existing About Us page</small>
          </div>
        </div>
      </section>

      <section className="section alt scroll" id="impact">
        <div className="container">
          <div className="head">
            <div>
              <div className="kicker">COMMUNITY &amp; IMPACT</div>
              <h2>
                Making an impact
                <br />
                beyond technology.
              </h2>
            </div>
            <p>
              qBotica&apos;s existing educational partnerships and community commitments belong here, separate from
              employee-only events and commercial workshops.
            </p>
          </div>
          <div className="community-layout">
            <article className="community-card">
              <div className="kicker">EDUCATION &amp; MENTORSHIP</div>
              <h3>Investing in the next generation</h3>
              <p>
                Mentorship, internships and hands-on learning opportunities connect emerging talent with experience in
                automation and AI.
              </p>
              <details className="accordion">
                <summary>How we support emerging talent</summary>
                <p>
                  qBotica&apos;s current About Us page describes guidance for students, young professionals and
                  entrepreneurs, along with internships that provide exposure to real projects.
                </p>
              </details>
            </article>
            <article className="community-card">
              <div className="kicker">PARTNERSHIPS</div>
              <h3>Connecting opportunity with innovation</h3>
              <p>
                Our current page features YLAI and Arizona State University as examples of qBotica&apos;s commitment to
                education and entrepreneurial development.
              </p>
              <details className="accordion">
                <summary>Explore partnership details</summary>
                <p>
                  YLAI focuses on emerging entrepreneurs. qBotica&apos;s ASU relationship emphasizes mentorship,
                  collaboration and practical exposure to intelligent automation.
                </p>
              </details>
            </article>
          </div>
          <div className="panel" style={{ marginTop: 17 }}>
            <div className="kicker">FUTURE STORY GALLERY</div>
            <h3>Community stories worth sharing</h3>
            <p>
              As verified U.S. and India CSR activities become available, this area can feature three rotating stories
              with approved photographs, short captions and links to deeper coverage. This avoids turning About Us into
              an endless events archive.
            </p>
            <div className="tags">
              {['Volunteering', 'Mentorship', 'Education'].map((t) => (
                <span key={t} className="tag" style={{ borderColor: '#d5deea', color: '#405875' }}>
                  {t}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="section scroll" id="locations">
        <div className="container">
          <div className="head">
            <div>
              <div className="kicker">OUR GLOBAL PRESENCE</div>
              <h2>
                Connected across
                <br />
                locations and teams.
              </h2>
            </div>
            <p>
              Explore the teams and places connecting qBotica across North America and Asia. Select a location to
              spotlight it on the globe.
            </p>
          </div>
          <div className="global-layout">
            <div className="globe-panel">
              <div className="globe-frame">
                <svg
                  aria-label="Illustrated interactive globe highlighting the United States, Canada and India in orange"
                  role="img"
                  viewBox="0 0 660 500"
                >
                  <defs>
                    <radialGradient cx="35%" cy="30%" id="qb-about-ocean">
                      <stop stopColor="#274b80" />
                      <stop offset="1" stopColor="#0b2148" />
                    </radialGradient>
                    <clipPath id="qb-about-globeclip">
                      <circle cx="330" cy="245" r="206" />
                    </clipPath>
                  </defs>
                  <circle cx="330" cy="245" fill="#f47a32" opacity=".10" r="218" />
                  <circle cx="330" cy="245" fill="url(#qb-about-ocean)" r="206" stroke="#8aa7d3" strokeWidth="2" />
                  <g clipPath="url(#qb-about-globeclip)">
                    <g fill="none" opacity=".19" stroke="#b4c9e5">
                      <ellipse cx="330" cy="245" rx="85" ry="206" />
                      <ellipse cx="330" cy="245" rx="160" ry="206" />
                      <path d="M124 245h412M147 155h366M147 335h366" />
                    </g>
                    <g fill="#6e8ca4" opacity=".82">
                      <path d="M130 120 171 83 230 70 270 93 279 128 255 144 242 173 210 183 198 215 164 207 152 171 123 154Z" />
                      <path d="M227 213 263 227 283 268 269 314 245 371 222 403 201 354 209 307 193 271Z" />
                      <path d="M319 101 362 80 413 91 450 78 504 111 531 143 508 172 483 176 469 194 454 198 445 215 459 239 450 267 434 300 423 276 413 247 408 218 386 209 354 190 335 158 302 141Z" />
                      <path d="M349 202 398 208 427 248 409 301 384 344 363 329 346 275 330 244Z" />
                      <path d="M471 336 510 342 542 370 531 397 489 402 465 380Z" />
                    </g>
                    <g className={cls('map-country', country === 'canada')}>
                      <path d="M138 113 176 87 229 76 255 92 265 119 237 137 206 135 184 151 154 141Z" />
                    </g>
                    <g className={cls('map-country', country === 'usa')}>
                      <path d="M154 151 186 155 205 142 235 145 251 161 239 188 216 195 199 218 166 202 155 179Z" />
                    </g>
                    <g className={cls('map-country', country === 'india')}>
                      <path d="M424 209 445 215 459 239 450 267 434 300 423 276 413 247 410 224Z" />
                    </g>
                  </g>
                  <circle cx="330" cy="245" fill="none" opacity=".6" r="206" stroke="#f7a76e" strokeWidth="2" />
                  <g className={cls('map-pin', country === 'usa')}>
                    <circle cx="193" cy="178" r="8" />
                    <text x="180" y="166">USA</text>
                  </g>
                  <g className={cls('map-pin', country === 'canada')}>
                    <circle cx="194" cy="120" r="8" />
                    <text x="204" y="111">CANADA</text>
                  </g>
                  <g className={cls('map-pin', country === 'india')}>
                    <circle cx="440" cy="247" r="8" />
                    <text x="451" y="239">INDIA</text>
                  </g>
                </svg>
              </div>
              <p className="map-note">Illustrative globe · not a precise geographic map</p>
            </div>
            <div className="location-cards">
              {locations.map((loc) => (
                <button
                  key={loc.country}
                  type="button"
                  className={cls('loc-card', country === loc.country)}
                  aria-pressed={country === loc.country}
                  onClick={() => setCountry(loc.country)}
                >
                  <div className={`loc-photo ${loc.photoClass}`}>
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={loc.img} alt={loc.alt} loading="lazy" />
                    <span>{loc.caption}</span>
                  </div>
                  <div className="loc-info">
                    <span className="loc-country">{loc.label}</span>
                    <h3>{loc.city}</h3>
                    <p>{loc.region}</p>
                    <span className="loc-action">Explore location ↗</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
          <p className="note">Landscape photos depict Phoenix, Chennai and New Brunswick, not qBotica offices.</p>
        </div>
      </section>

      <section className="footer-cta">
        <div className="container">
          <div className="kicker" style={{ color: '#f5a571' }}>CONTINUE THE QBOTICA STORY</div>
          <h2>
            See what our people
            <br />
            make possible.
          </h2>
          <p>
            From company culture to real customer outcomes, discover how qBotica turns ambitious ideas into meaningful
            execution.
          </p>
          <div className="hero-actions">
            <a className="btn primary" href="/customer-success-stories">Customer Stories ↗</a>
            <a className="btn ghost" href="/newsroom">Newsroom ↗</a>
            <a className="btn ghost" href="/careers">Careers ↗</a>
          </div>
        </div>
      </section>
    </div>
  );
}
